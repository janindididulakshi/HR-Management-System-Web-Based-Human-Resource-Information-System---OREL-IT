-- Migration: Add notifications table and profile picture columns
-- Date: 2026-01-08

-- Add profile_picture column to employees table
ALTER TABLE employees 
ADD COLUMN IF NOT EXISTS profile_picture VARCHAR(255);

-- Add profile_picture and name columns to users table (for admin)
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS profile_picture VARCHAR(255),
ADD COLUMN IF NOT EXISTS name VARCHAR(255);

-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
    id BIGINT PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
    recipient_email VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL, -- 'leave', 'attendance', 'payslip'
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_notifications_recipient ON notifications(recipient_email);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);
CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON notifications(created_at DESC);

-- Add email column to employees table if it doesn't exist (for notifications)
ALTER TABLE employees 
ADD COLUMN IF NOT EXISTS email VARCHAR(255);

-- Update employees email from users table where email is null
UPDATE employees e
SET email = u.email
FROM users u
WHERE e.user_id = u.id AND e.email IS NULL;

COMMENT ON TABLE notifications IS 'Stores system notifications for users';
COMMENT ON COLUMN employees.profile_picture IS 'Path to employee profile picture';
COMMENT ON COLUMN users.profile_picture IS 'Path to admin profile picture';
COMMENT ON COLUMN users.name IS 'Admin full name';
