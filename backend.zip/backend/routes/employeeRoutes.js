import express from 'express';
import supabase from '../config/database.js';
import { authenticateToken, authorizeRole } from '../middleware/auth.js';
import upload from '../middleware/upload.js';

const router = express.Router();

// Apply authentication and employee authorization to all routes
router.use(authenticateToken);
router.use(authorizeRole('employee'));

// Get employee ID from user ID
const getEmployeeId = async (userId) => {
  const { data, error } = await supabase
    .from('employees')
    .select('id')
    .eq('user_id', userId)
    .single();
  
  return data ? data.id : null;
};

// Helper function to notify all admins
const notifyAdmins = async (message) => {
  try {
    // 1. Get all admin user IDs
    const { data: admins, error: adminError } = await supabase
      .from('users')
      .select('id')
      .eq('role', 'admin');

    if (adminError) throw adminError;

    if (admins && admins.length > 0) {
      // 2. Create a notification for each admin
      const notifications = admins.map(admin => ({
        user_id: admin.id,
        message,
        type: 'info'
      }));
      
      const { error: notificationError } = await supabase
        .from('notifications')
        .insert(notifications);

      if (notificationError) throw notificationError;
    }
  } catch (error) {
    console.error('Failed to send admin notifications:', error);
    // We don't want to fail the main request if notifications fail
  }
};

// ===== DASHBOARD =====

router.get('/dashboard/stats', async (req, res) => {
  try {
    const employeeId = await getEmployeeId(req.user.id);
    
    if (!employeeId) {
      return res.status(404).json({ message: 'Employee record not found' });
    }

    const currentYear = new Date().getFullYear();

    // Count approved leaves for current year
    const { count: leavesTaken } = await supabase
      .from('leaves')
      .select('*', { count: 'exact', head: true })
      .eq('employee_id', employeeId)
      .eq('status', 'approved')
      .gte('from_date', `${currentYear}-01-01`);

    // Count pending leaves
    const { count: pendingLeaves } = await supabase
      .from('leaves')
      .select('*', { count: 'exact', head: true })
      .eq('employee_id', employeeId)
      .eq('status', 'pending');

    // Count pending attendance issues
    const { count: attendanceIssues } = await supabase
      .from('attendance')
      .select('*', { count: 'exact', head: true })
      .eq('employee_id', employeeId)
      .eq('status', 'pending');

    // Count payslips
    const { count: payslipsCount } = await supabase
      .from('payslips')
      .select('*', { count: 'exact', head: true })
      .eq('employee_id', employeeId);

    res.json({
      leavesTaken: leavesTaken || 0,
      pendingLeaves: pendingLeaves || 0,
      attendanceIssues: attendanceIssues || 0,
      payslipsCount: payslipsCount || 0
    });
  } catch (error) {
    console.error('Dashboard stats error:', error);
    res.status(500).json({ message: 'Failed to fetch dashboard stats' });
  }
});

// ===== PROFILE =====

router.get('/profile', async (req, res) => {
  try {
    const { data: employee, error } = await supabase
      .from('employees')
      .select('*, users(email)')
      .eq('user_id', req.user.id)
      .single();

    if (error || !employee) {
      return res.status(404).json({ message: 'Profile not found' });
    }

    // Flatten the users object and remove sensitive data
    const profile = {
      ...employee,
      email: employee.users?.email,
      users: undefined,
      user_id: undefined
    };

    res.json(profile);
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({ message: 'Failed to fetch profile' });
  }
});

router.put('/profile', async (req, res) => {
  try {
    const { phone, address } = req.body;
    const employeeId = await getEmployeeId(req.user.id);

    if (!employeeId) {
      return res.status(404).json({ message: 'Employee record not found' });
    }

    const { error } = await supabase
      .from('employees')
      .update({ phone, address })
      .eq('id', employeeId);

    if (error) throw error;

    res.json({ message: 'Profile updated successfully' });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ message: 'Failed to update profile' });
  }
});

// Upload profile picture
router.post('/profile/picture', upload.single('profile_picture'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }

    const employeeId = await getEmployeeId(req.user.id);
    if (!employeeId) {
      return res.status(404).json({ message: 'Employee record not found' });
    }

    const profilePicturePath = `/uploads/${req.file.filename}`;

    const { error } = await supabase
      .from('employees')
      .update({ profile_picture: profilePicturePath })
      .eq('id', employeeId);

    if (error) throw error;

    res.json({ 
      message: 'Profile picture uploaded successfully',
      profile_picture: profilePicturePath
    });
  } catch (error) {
    console.error('Upload profile picture error:', error);
    res.status(500).json({ message: error.message || 'Failed to upload profile picture' });
  }
});

// ===== LEAVE REQUESTS =====

router.get('/leaves', async (req, res) => {
  try {
    const employeeId = await getEmployeeId(req.user.id);

    if (!employeeId) {
      return res.status(404).json({ message: 'Employee record not found' });
    }

    const { data: leaves, error } = await supabase
      .from('leaves')
      .select('*')
      .eq('employee_id', employeeId)
      .order('created_at', { ascending: false });

    if (error) throw error;

    res.json(leaves || []);
  } catch (error) {
    console.error('Get leaves error:', error);
    res.status(500).json({ message: 'Failed to fetch leave requests' });
  }
});

router.post('/leaves', async (req, res) => {
  try {
    const { type, from_date, to_date, reason } = req.body;
    const employeeId = await getEmployeeId(req.user.id);

    if (!employeeId) {
      return res.status(404).json({ message: 'Employee record not found' });
    }

    const { data, error } = await supabase
      .from('leaves')
      .insert({
        employee_id: employeeId,
        type,
        from_date,
        to_date,
        reason
      })
      .select()
      .single();

    if (error) throw error;

    // Notify admins
    const { data: employee, error: empError } = await supabase
      .from('employees')
      .select('name')
      .eq('id', employeeId)
      .single();
      
    if (employee) {
      await notifyAdmins(`New leave request from ${employee.name}.`);
    }

    res.status(201).json({ 
      message: 'Leave request submitted successfully',
      leaveId: data.id
    });
  } catch (error) {
    console.error('Create leave error:', error);
    res.status(500).json({ message: 'Failed to submit leave request' });
  }
});

// ===== ATTENDANCE ISSUES =====

router.get('/attendance', async (req, res) => {
  try {
    const employeeId = await getEmployeeId(req.user.id);

    if (!employeeId) {
      return res.status(404).json({ message: 'Employee record not found' });
    }

    const { data: attendance, error } = await supabase
      .from('attendance')
      .select('*')
      .eq('employee_id', employeeId)
      .order('created_at', { ascending: false });

    if (error) throw error;

    res.json(attendance || []);
  } catch (error) {
    console.error('Get attendance error:', error);
    res.status(500).json({ message: 'Failed to fetch attendance records' });
  }
});

router.post('/attendance', async (req, res) => {
  try {
    const { date, time_in, time_out, reason } = req.body;
    const employeeId = await getEmployeeId(req.user.id);

    if (!employeeId) {
      return res.status(404).json({ message: 'Employee record not found' });
    }

    const { data, error } = await supabase
      .from('attendance')
      .insert({
        employee_id: employeeId,
        date,
        time_in,
        time_out,
        reason
      })
      .select()
      .single();

    if (error) throw error;

    // Notify admins
    const { data: employee, error: empError } = await supabase
      .from('employees')
      .select('name')
      .eq('id', employeeId)
      .single();

    if (employee) {
      await notifyAdmins(`New attendance issue reported by ${employee.name}.`);
    }

    res.status(201).json({ 
      message: 'Attendance issue submitted successfully',
      attendanceId: data.id
    });
  } catch (error) {
    console.error('Create attendance error:', error);
    res.status(500).json({ message: 'Failed to submit attendance issue' });
  }
});

// ===== PAYSLIPS =====

router.get('/payslips', async (req, res) => {
  try {
    const employeeId = await getEmployeeId(req.user.id);

    if (!employeeId) {
      return res.status(404).json({ message: 'Employee record not found' });
    }

    const { data: payslips, error } = await supabase
      .from('payslips')
      .select('*')
      .eq('employee_id', employeeId)
      .order('year', { ascending: false })
      .order('month', { ascending: false });

    if (error) throw error;

    res.json(payslips || []);
  } catch (error) {
    console.error('Get payslips error:', error);
    res.status(500).json({ message: 'Failed to fetch payslips' });
  }
});

router.get('/payslips/:id', async (req, res) => {
  try {
    const employeeId = await getEmployeeId(req.user.id);

    if (!employeeId) {
      return res.status(404).json({ message: 'Employee record not found' });
    }

    const { data: payslip, error } = await supabase
      .from('payslips')
      .select('*')
      .eq('id', req.params.id)
      .eq('employee_id', employeeId)
      .single();

    if (error || !payslip) {
      return res.status(404).json({ message: 'Payslip not found' });
    }

    res.json(payslip);
  } catch (error) {
    console.error('Get payslip error:', error);
    res.status(500).json({ message: 'Failed to fetch payslip' });
  }
});

export default router;
