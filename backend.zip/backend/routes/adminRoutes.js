import express from 'express';
import bcrypt from 'bcryptjs';
import supabase from '../config/database.js';
import { authenticateToken, authorizeRole } from '../middleware/auth.js';
import upload from '../middleware/upload.js';
import { createNotification } from './notificationRoutes.js';

const router = express.Router();

// Apply authentication and admin authorization to all routes
router.use(authenticateToken);
router.use(authorizeRole('admin'));

// ===== ADMIN PROFILE =====

// Get admin profile
router.get('/profile', async (req, res) => {
  try {
    const { data: user, error } = await supabase
      .from('users')
      .select('id, email, name, profile_picture')
      .eq('id', req.user.id)
      .eq('role', 'admin')
      .single();

    if (error || !user) {
      return res.status(404).json({ message: 'Profile not found' });
    }

    res.json(user);
  } catch (error) {
    console.error('Get admin profile error:', error);
    res.status(500).json({ message: 'Failed to fetch profile' });
  }
});

// Update admin profile
router.put('/profile', async (req, res) => {
  try {
    const { name } = req.body;

    const { error } = await supabase
      .from('users')
      .update({ name })
      .eq('id', req.user.id);

    if (error) throw error;

    res.json({ message: 'Profile updated successfully' });
  } catch (error) {
    console.error('Update admin profile error:', error);
    res.status(500).json({ message: 'Failed to update profile' });
  }
});

// Upload admin profile picture
router.post('/profile/picture', upload.single('profile_picture'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }

    const profilePicturePath = `/uploads/${req.file.filename}`;

    const { error } = await supabase
      .from('users')
      .update({ profile_picture: profilePicturePath })
      .eq('id', req.user.id);

    if (error) throw error;

    res.json({ 
      message: 'Profile picture uploaded successfully',
      profile_picture: profilePicturePath
    });
  } catch (error) {
    console.error('Upload admin profile picture error:', error);
    res.status(500).json({ message: error.message || 'Failed to upload profile picture' });
  }
});

// Dashboard Stats
router.get('/dashboard/stats', async (req, res) => {
  try {
    const { count: employeeCount } = await supabase
      .from('employees')
      .select('*', { count: 'exact', head: true });

    const { count: pendingLeaves } = await supabase
      .from('leaves')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'pending');

    const { count: pendingAttendance } = await supabase
      .from('attendance')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'pending');

    const currentMonth = new Date().toLocaleString('default', { month: 'long' });
    const currentYear = new Date().getFullYear();

    const { data: payrollData } = await supabase
      .from('payslips')
      .select('net_salary')
      .eq('month', currentMonth)
      .eq('year', currentYear);

    const payrollTotal = payrollData?.reduce((sum, p) => sum + parseFloat(p.net_salary || 0), 0) || 0;

    res.json({
      totalEmployees: employeeCount || 0,
      pendingLeaves: pendingLeaves || 0,
      pendingAttendance: pendingAttendance || 0,
      payrollTotal: payrollTotal
    });
  } catch (error) {
    console.error('Dashboard stats error:', error);
    res.status(500).json({ message: 'Failed to fetch dashboard stats' });
  }
});

// ===== EMPLOYEE MANAGEMENT =====

// Get all employees
router.get('/employees', async (req, res) => {
  try {
    const { search, department, status } = req.query;
    
    let query = supabase
      .from('employees')
      .select('*, users!inner(email, status)');

    if (search) {
      query = query.or(`name.ilike.%${search}%,emp_id.ilike.%${search}%`);
    }

    if (department) {
      query = query.eq('department', department);
    }

    if (status) {
      query = query.eq('users.status', status);
    }

    query = query.order('created_at', { ascending: false });

    const { data: employees, error } = await query;

    if (error) throw error;

    // Flatten the users object for compatibility
    const formattedEmployees = employees?.map(emp => ({
      ...emp,
      email: emp.users?.email,
      account_status: emp.users?.status,
      users: undefined
    })) || [];

    res.json(formattedEmployees);
  } catch (error) {
    console.error('Get employees error:', error);
    res.status(500).json({ message: 'Failed to fetch employees' });
  }
});

// Get single employee
router.get('/employees/:id', async (req, res) => {
  try {
    const { data: employees, error } = await supabase
      .from('employees')
      .select('*, users(email, status)')
      .eq('id', req.params.id)
      .single();

    if (error || !employees) {
      return res.status(404).json({ message: 'Employee not found' });
    }

    // Flatten the users object
    const employee = {
      ...employees,
      email: employees.users?.email,
      account_status: employees.users?.status,
      users: undefined
    };

    res.json(employee);
  } catch (error) {
    console.error('Get employee error:', error);
    res.status(500).json({ message: 'Failed to fetch employee' });
  }
});

// Create employee
router.post('/employees', async (req, res) => {
  try {
    const {
      email, name, emp_id, nic, department, designation,
      salary, join_date, phone, address
    } = req.body;

    // Generate temporary password
    const tempPassword = `Temp${Math.random().toString(36).slice(-8)}`;
    const hashedPassword = await bcrypt.hash(tempPassword, 10);

    // Create user account
    const { data: userData, error: userError } = await supabase
      .from('users')
      .insert({
        email,
        password: hashedPassword,
        role: 'employee',
        must_change_password: true
      })
      .select()
      .single();

    if (userError) {
      if (userError.code === '23505') { // Unique violation
        return res.status(400).json({ message: 'Email already exists' });
      }
      throw userError;
    }

    // Create employee record
    const { data: employeeData, error: employeeError } = await supabase
      .from('employees')
      .insert({
        user_id: userData.id,
        emp_id,
        name,
        nic,
        department,
        designation,
        salary,
        join_date,
        phone,
        address
      })
      .select()
      .single();

    if (employeeError) {
      // Rollback: delete the user if employee creation fails
      await supabase.from('users').delete().eq('id', userData.id);
      
      if (employeeError.code === '23505') {
        return res.status(400).json({ message: 'Employee ID already exists' });
      }
      throw employeeError;
    }

    res.status(201).json({
      message: 'Employee created successfully',
      employeeId: employeeData.id,
      tempPassword, // In production, send this via email
      email
    });
  } catch (error) {
    console.error('Create employee error:', error);
    res.status(500).json({ message: 'Failed to create employee' });
  }
});

// Update employee
router.put('/employees/:id', async (req, res) => {
  try {
    const {
      name, nic, department, designation, salary,
      join_date, phone, address
    } = req.body;

    const { error } = await supabase
      .from('employees')
      .update({
        name,
        nic,
        department,
        designation,
        salary,
        join_date,
        phone,
        address
      })
      .eq('id', req.params.id);

    if (error) throw error;

    res.json({ message: 'Employee updated successfully' });
  } catch (error) {
    console.error('Update employee error:', error);
    res.status(500).json({ message: 'Failed to update employee' });
  }
});

// Delete employee
router.delete('/employees/:id', async (req, res) => {
  try {
    // Get user_id
    const { data: employee, error: selectError } = await supabase
      .from('employees')
      .select('user_id')
      .eq('id', req.params.id)
      .single();

    if (selectError || !employee) {
      return res.status(404).json({ message: 'Employee not found' });
    }

    // Delete user (cascade will delete employee)
    const { error: deleteError } = await supabase
      .from('users')
      .delete()
      .eq('id', employee.user_id);

    if (deleteError) throw deleteError;

    res.json({ message: 'Employee deleted successfully' });
  } catch (error) {
    console.error('Delete employee error:', error);
    res.status(500).json({ message: 'Failed to delete employee' });
  }
});

// Toggle employee status
router.patch('/employees/:id/status', async (req, res) => {
  try {
    const { status } = req.body;

    const { data: employee, error: selectError } = await supabase
      .from('employees')
      .select('user_id')
      .eq('id', req.params.id)
      .single();

    if (selectError || !employee) {
      return res.status(404).json({ message: 'Employee not found' });
    }

    const { error: updateError } = await supabase
      .from('users')
      .update({ status })
      .eq('id', employee.user_id);

    if (updateError) throw updateError;

    res.json({ message: `Employee ${status === 'active' ? 'activated' : 'deactivated'} successfully` });
  } catch (error) {
    console.error('Toggle status error:', error);
    res.status(500).json({ message: 'Failed to update employee status' });
  }
});

// ===== LEAVE MANAGEMENT =====

// Get all leave requests
router.get('/leaves', async (req, res) => {
  try {
    const { status, employee_id } = req.query;

    let query = supabase
      .from('leaves')
      .select('*, employees(name, emp_id, department)');

    if (status) {
      query = query.eq('status', status);
    }

    if (employee_id) {
      query = query.eq('employee_id', employee_id);
    }

    query = query.order('created_at', { ascending: false });

    const { data: leaves, error } = await query;

    if (error) throw error;

    // Flatten employee data
    const formattedLeaves = leaves?.map(leave => ({
      ...leave,
      employee_name: leave.employees?.name,
      emp_id: leave.employees?.emp_id,
      department: leave.employees?.department,
      employees: undefined
    })) || [];

    res.json(formattedLeaves);
  } catch (error) {
    console.error('Get leaves error:', error);
    res.status(500).json({ message: 'Failed to fetch leave requests' });
  }
});

// Update leave status
router.patch('/leaves/:id', async (req, res) => {
  try {
    const { status, remarks } = req.body;

    // Get leave details with employee email
    const { data: leave, error: leaveError } = await supabase
      .from('leaves')
      .select('*, employees(name, email)')
      .eq('id', req.params.id)
      .single();

    if (leaveError || !leave) {
      return res.status(404).json({ message: 'Leave request not found' });
    }

    const { error } = await supabase
      .from('leaves')
      .update({ status, remarks })
      .eq('id', req.params.id);

    if (error) throw error;

    // Create notification
    const notificationTitle = `Leave Request ${status.charAt(0).toUpperCase() + status.slice(1)}`;
    const notificationMessage = `Your leave request from ${leave.from_date} to ${leave.to_date} has been ${status}. ${remarks ? 'Remarks: ' + remarks : ''}`;
    
    await createNotification(
      leave.employees.email,
      'leave',
      notificationTitle,
      notificationMessage
    );

    res.json({ message: `Leave ${status} successfully` });
  } catch (error) {
    console.error('Update leave error:', error);
    res.status(500).json({ message: 'Failed to update leave status' });
  }
});

// ===== ATTENDANCE MANAGEMENT =====

// Get all attendance issues
router.get('/attendance', async (req, res) => {
  try {
    const { status, employee_id } = req.query;

    let query = supabase
      .from('attendance')
      .select('*, employees(name, emp_id, department)');

    if (status) {
      query = query.eq('status', status);
    }

    if (employee_id) {
      query = query.eq('employee_id', employee_id);
    }

    query = query.order('created_at', { ascending: false });

    const { data: attendance, error } = await query;

    if (error) throw error;

    // Flatten employee data
    const formattedAttendance = attendance?.map(att => ({
      ...att,
      employee_name: att.employees?.name,
      emp_id: att.employees?.emp_id,
      department: att.employees?.department,
      employees: undefined
    })) || [];

    res.json(formattedAttendance);
  } catch (error) {
    console.error('Get attendance error:', error);
    res.status(500).json({ message: 'Failed to fetch attendance records' });
  }
});

// Update attendance status
router.patch('/attendance/:id', async (req, res) => {
  try {
    const { status, remarks } = req.body;

    // Get attendance details with employee email
    const { data: attendance, error: attendanceError } = await supabase
      .from('attendance')
      .select('*, employees(name, email)')
      .eq('id', req.params.id)
      .single();

    if (attendanceError || !attendance) {
      return res.status(404).json({ message: 'Attendance issue not found' });
    }

    const { error } = await supabase
      .from('attendance')
      .update({ status, remarks })
      .eq('id', req.params.id);

    if (error) throw error;

    // Create notification
    const notificationTitle = `Attendance Issue ${status.charAt(0).toUpperCase() + status.slice(1)}`;
    const notificationMessage = `Your attendance issue for ${attendance.date} has been ${status}. ${remarks ? 'Remarks: ' + remarks : ''}`;
    
    await createNotification(
      attendance.employees.email,
      'attendance',
      notificationTitle,
      notificationMessage
    );

    res.json({ message: `Attendance ${status} successfully` });
  } catch (error) {
    console.error('Update attendance error:', error);
    res.status(500).json({ message: 'Failed to update attendance status' });
  }
});

// ===== PAYROLL MANAGEMENT =====

// Get all payslips
router.get('/payslips', async (req, res) => {
  try {
    const { employee_id, month, year } = req.query;

    let query = supabase
      .from('payslips')
      .select('*, employees(name, emp_id, department)');

    if (employee_id) {
      query = query.eq('employee_id', employee_id);
    }

    if (month) {
      query = query.eq('month', month);
    }

    if (year) {
      query = query.eq('year', year);
    }

    query = query.order('created_at', { ascending: false });

    const { data: payslips, error } = await query;

    if (error) throw error;

    // Flatten employee data
    const formattedPayslips = payslips?.map(payslip => ({
      ...payslip,
      employee_name: payslip.employees?.name,
      emp_id: payslip.employees?.emp_id,
      department: payslip.employees?.department,
      employees: undefined
    })) || [];

    res.json(formattedPayslips);
  } catch (error) {
    console.error('Get payslips error:', error);
    res.status(500).json({ message: 'Failed to fetch payslips' });
  }
});

// Create/Generate payslip
router.post('/payslips', async (req, res) => {
  try {
    const { employee_id, month, year, basic_salary, allowances, deductions } = req.body;

    const net_salary = parseFloat(basic_salary) + parseFloat(allowances || 0) - parseFloat(deductions || 0);

    // Get employee email
    const { data: employee, error: empError } = await supabase
      .from('employees')
      .select('name, email')
      .eq('id', employee_id)
      .single();

    if (empError || !employee) {
      return res.status(404).json({ message: 'Employee not found' });
    }

    const { data, error } = await supabase
      .from('payslips')
      .insert({
        employee_id,
        month,
        year,
        basic_salary,
        allowances: allowances || 0,
        deductions: deductions || 0,
        net_salary
      })
      .select()
      .single();

    if (error) {
      if (error.code === '23505') { // Unique violation
        return res.status(400).json({ message: 'Payslip already exists for this month and year' });
      }
      throw error;
    }

    // Create notification
    const notificationTitle = 'Payslip Released';
    const notificationMessage = `Your payslip for ${month} ${year} has been released. Net Salary: $${net_salary.toFixed(2)}`;
    
    await createNotification(
      employee.email,
      'payslip',
      notificationTitle,
      notificationMessage
    );

    res.status(201).json({
      message: 'Payslip generated successfully',
      payslip: data
    });
  } catch (error) {
    console.error('Create payslip error:', error);
    res.status(500).json({ message: 'Failed to generate payslip' });
  }
});

export default router;
