import express from 'express';
import bcrypt from 'bcryptjs';
import pool from '../config/database.js';
import { authenticateToken, authorizeRole } from '../middleware/auth.js';

const router = express.Router();

// Apply authentication and admin authorization to all routes
router.use(authenticateToken);
router.use(authorizeRole('admin'));

// Dashboard Stats
router.get('/dashboard/stats', async (req, res) => {
  try {
    const [employeeCount] = await pool.query('SELECT COUNT(*) as count FROM employees');
    const [pendingLeaves] = await pool.query('SELECT COUNT(*) as count FROM leaves WHERE status = "pending"');
    const [pendingAttendance] = await pool.query('SELECT COUNT(*) as count FROM attendance WHERE status = "pending"');
    const [payrollTotal] = await pool.query('SELECT SUM(net_salary) as total FROM payslips WHERE month = MONTHNAME(CURDATE()) AND year = YEAR(CURDATE())');

    res.json({
      totalEmployees: employeeCount[0].count,
      pendingLeaves: pendingLeaves[0].count,
      pendingAttendance: pendingAttendance[0].count,
      payrollTotal: payrollTotal[0].total || 0
    });
  } catch (error) {
    console.error('Dashboard stats error:', error);
    res.status(500).json({ message: 'Failed to fetch dashboard stats' });
  }
});

// ===== EMPLOYEE MANAGEMENT =====

// Get all employees
router.get('/employees', async (req, res) => {
  try {
    const { search, department, status } = req.query;
    let query = `SELECT e.*, u.email, u.status as account_status 
                 FROM employees e 
                 LEFT JOIN users u ON e.user_id = u.id WHERE 1=1`;
    const params = [];

    if (search) {
      query += ` AND (e.name LIKE ? OR e.emp_id LIKE ? OR e.email LIKE ?)`;
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    if (department) {
      query += ` AND e.department = ?`;
      params.push(department);
    }

    if (status) {
      query += ` AND u.status = ?`;
      params.push(status);
    }

    query += ' ORDER BY e.created_at DESC';

    const [employees] = await pool.query(query, params);
    res.json(employees);
  } catch (error) {
    console.error('Get employees error:', error);
    res.status(500).json({ message: 'Failed to fetch employees' });
  }
});

// Get single employee
router.get('/employees/:id', async (req, res) => {
  try {
    const [employees] = await pool.query(
      `SELECT e.*, u.email, u.status as account_status 
       FROM employees e 
       LEFT JOIN users u ON e.user_id = u.id 
       WHERE e.id = ?`,
      [req.params.id]
    );

    if (employees.length === 0) {
      return res.status(404).json({ message: 'Employee not found' });
    }

    res.json(employees[0]);
  } catch (error) {
    console.error('Get employee error:', error);
    res.status(500).json({ message: 'Failed to fetch employee' });
  }
});

// Create employee
router.post('/employees', async (req, res) => {
  const connection = await pool.getConnection();
  
  try {
    await connection.beginTransaction();

    const {
      email, name, emp_id, nic, department, designation,
      salary, join_date, phone, address
    } = req.body;

    // Generate temporary password
    const tempPassword = `Temp${Math.random().toString(36).slice(-8)}`;
    const hashedPassword = await bcrypt.hash(tempPassword, 10);

    // Create user account
    const [userResult] = await connection.query(
      'INSERT INTO users (email, password, role, must_change_password) VALUES (?, ?, ?, ?)',
      [email, hashedPassword, 'employee', true]
    );

    const userId = userResult.insertId;

    // Create employee record
    const [employeeResult] = await connection.query(
      `INSERT INTO employees (user_id, emp_id, name, nic, department, designation, salary, join_date, phone, address) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [userId, emp_id, name, nic, department, designation, salary, join_date, phone, address]
    );

    await connection.commit();

    res.status(201).json({
      message: 'Employee created successfully',
      employeeId: employeeResult.insertId,
      tempPassword, // In production, send this via email
      email
    });
  } catch (error) {
    await connection.rollback();
    console.error('Create employee error:', error);
    
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ message: 'Email or Employee ID already exists' });
    }
    
    res.status(500).json({ message: 'Failed to create employee' });
  } finally {
    connection.release();
  }
});

// Update employee
router.put('/employees/:id', async (req, res) => {
  try {
    const {
      name, nic, department, designation, salary,
      join_date, phone, address
    } = req.body;

    await pool.query(
      `UPDATE employees SET name = ?, nic = ?, department = ?, designation = ?, 
       salary = ?, join_date = ?, phone = ?, address = ? WHERE id = ?`,
      [name, nic, department, designation, salary, join_date, phone, address, req.params.id]
    );

    res.json({ message: 'Employee updated successfully' });
  } catch (error) {
    console.error('Update employee error:', error);
    res.status(500).json({ message: 'Failed to update employee' });
  }
});

// Delete employee
router.delete('/employees/:id', async (req, res) => {
  const connection = await pool.getConnection();
  
  try {
    await connection.beginTransaction();

    // Get user_id
    const [employees] = await connection.query('SELECT user_id FROM employees WHERE id = ?', [req.params.id]);
    
    if (employees.length === 0) {
      return res.status(404).json({ message: 'Employee not found' });
    }

    const userId = employees[0].user_id;

    // Delete employee (cascade will delete user)
    await connection.query('DELETE FROM users WHERE id = ?', [userId]);

    await connection.commit();
    res.json({ message: 'Employee deleted successfully' });
  } catch (error) {
    await connection.rollback();
    console.error('Delete employee error:', error);
    res.status(500).json({ message: 'Failed to delete employee' });
  } finally {
    connection.release();
  }
});

// Toggle employee status
router.patch('/employees/:id/status', async (req, res) => {
  try {
    const { status } = req.body;

    const [employees] = await pool.query('SELECT user_id FROM employees WHERE id = ?', [req.params.id]);
    
    if (employees.length === 0) {
      return res.status(404).json({ message: 'Employee not found' });
    }

    await pool.query('UPDATE users SET status = ? WHERE id = ?', [status, employees[0].user_id]);

    res.json({ message: `Employee ${status === 'active' ? 'activated' : 'deactivated'} successfully` });
  } catch (error) {
    console.error('Toggle status error:', error);
    res.status(500).json({ message: 'Failed to update employee status' });
  }
});

// ===== LEAVE MANAGEMENT =====

// Get all leave requests
router.get('/leaves', async (req, res) => {
  try {
    const { status, employee_id } = req.query;
    let query = `SELECT l.*, e.name as employee_name, e.emp_id, e.department 
                 FROM leaves l 
                 JOIN employees e ON l.employee_id = e.id WHERE 1=1`;
    const params = [];

    if (status) {
      query += ` AND l.status = ?`;
      params.push(status);
    }

    if (employee_id) {
      query += ` AND l.employee_id = ?`;
      params.push(employee_id);
    }

    query += ' ORDER BY l.created_at DESC';

    const [leaves] = await pool.query(query, params);
    res.json(leaves);
  } catch (error) {
    console.error('Get leaves error:', error);
    res.status(500).json({ message: 'Failed to fetch leave requests' });
  }
});

// Update leave status
router.patch('/leaves/:id', async (req, res) => {
  try {
    const { status, remarks } = req.body;

    await pool.query(
      'UPDATE leaves SET status = ?, remarks = ? WHERE id = ?',
      [status, remarks, req.params.id]
    );

    res.json({ message: `Leave ${status} successfully` });
  } catch (error) {
    console.error('Update leave error:', error);
    res.status(500).json({ message: 'Failed to update leave status' });
  }
});

// ===== ATTENDANCE MANAGEMENT =====

// Get all attendance issues
router.get('/attendance', async (req, res) => {
  try {
    const { status, employee_id } = req.query;
    let query = `SELECT a.*, e.name as employee_name, e.emp_id, e.department 
                 FROM attendance a 
                 JOIN employees e ON a.employee_id = e.id WHERE 1=1`;
    const params = [];

    if (status) {
      query += ` AND a.status = ?`;
      params.push(status);
    }

    if (employee_id) {
      query += ` AND a.employee_id = ?`;
      params.push(employee_id);
    }

    query += ' ORDER BY a.created_at DESC';

    const [attendance] = await pool.query(query, params);
    res.json(attendance);
  } catch (error) {
    console.error('Get attendance error:', error);
    res.status(500).json({ message: 'Failed to fetch attendance records' });
  }
});

// Update attendance status
router.patch('/attendance/:id', async (req, res) => {
  try {
    const { status, remarks } = req.body;

    await pool.query(
      'UPDATE attendance SET status = ?, remarks = ? WHERE id = ?',
      [status, remarks, req.params.id]
    );

    res.json({ message: `Attendance ${status} successfully` });
  } catch (error) {
    console.error('Update attendance error:', error);
    res.status(500).json({ message: 'Failed to update attendance status' });
  }
});

// ===== PAYROLL MANAGEMENT =====

// Get all payslips
router.get('/payslips', async (req, res) => {
  try {
    const { employee_id, month, year } = req.query;
    let query = `SELECT p.*, e.name as employee_name, e.emp_id, e.department 
                 FROM payslips p 
                 JOIN employees e ON p.employee_id = e.id WHERE 1=1`;
    const params = [];

    if (employee_id) {
      query += ` AND p.employee_id = ?`;
      params.push(employee_id);
    }

    if (month) {
      query += ` AND p.month = ?`;
      params.push(month);
    }

    if (year) {
      query += ` AND p.year = ?`;
      params.push(year);
    }

    query += ' ORDER BY p.created_at DESC';

    const [payslips] = await pool.query(query, params);
    res.json(payslips);
  } catch (error) {
    console.error('Get payslips error:', error);
    res.status(500).json({ message: 'Failed to fetch payslips' });
  }
});

// Create/Generate payslip
router.post('/payslips', async (req, res) => {
  try {
    const { employee_id, month, year, basic_salary, allowances, deductions } = req.body;

    const net_salary = parseFloat(basic_salary) + parseFloat(allowances || 0) - parseFloat(deductions || 0);

    const [result] = await pool.query(
      `INSERT INTO payslips (employee_id, month, year, basic_salary, allowances, deductions, net_salary) 
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [employee_id, month, year, basic_salary, allowances || 0, deductions || 0, net_salary]
    );

    res.status(201).json({ 
      message: 'Payslip generated successfully',
      payslipId: result.insertId
    });
  } catch (error) {
    console.error('Create payslip error:', error);
    
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ message: 'Payslip already exists for this employee and month' });
    }
    
    res.status(500).json({ message: 'Failed to generate payslip' });
  }
});

export default router;
