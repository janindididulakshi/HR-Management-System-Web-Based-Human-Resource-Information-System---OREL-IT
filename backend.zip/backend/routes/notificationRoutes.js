import express from 'express';
import supabase from '../config/database.js';
import { authenticateToken } from '../middleware/auth.js';

const router = express.Router();

// Apply authentication to all routes
router.use(authenticateToken);

// Get employee ID from user ID
const getEmployeeId = async (userId) => {
  const { data, error } = await supabase
    .from('employees')
    .select('id, email')
    .eq('user_id', userId)
    .single();
  
  return data ? { id: data.id, email: data.email } : null;
};

// Get all notifications for logged-in user
router.get('/', async (req, res) => {
  try {
    let userId = req.user.id;
    let userEmail = req.user.email;

    // If employee, get employee email
    if (req.user.role === 'employee') {
      const employeeData = await getEmployeeId(userId);
      if (employeeData) {
        userEmail = employeeData.email;
      }
    }

    const { data: notifications, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('recipient_email', userEmail)
      .order('created_at', { ascending: false });

    if (error) throw error;

    res.json(notifications || []);
  } catch (error) {
    console.error('Get notifications error:', error);
    res.status(500).json({ message: 'Failed to fetch notifications' });
  }
});

// Get unread notification count
router.get('/unread-count', async (req, res) => {
  try {
    let userId = req.user.id;
    let userEmail = req.user.email;

    // If employee, get employee email
    if (req.user.role === 'employee') {
      const employeeData = await getEmployeeId(userId);
      if (employeeData) {
        userEmail = employeeData.email;
      }
    }

    const { count, error } = await supabase
      .from('notifications')
      .select('*', { count: 'exact', head: true })
      .eq('recipient_email', userEmail)
      .eq('is_read', false);

    if (error) throw error;

    res.json({ count: count || 0 });
  } catch (error) {
    console.error('Get unread count error:', error);
    res.status(500).json({ message: 'Failed to fetch unread count' });
  }
});

// Mark notification as read
router.patch('/:id/read', async (req, res) => {
  try {
    const { error } = await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('id', req.params.id);

    if (error) throw error;

    res.json({ message: 'Notification marked as read' });
  } catch (error) {
    console.error('Mark notification as read error:', error);
    res.status(500).json({ message: 'Failed to mark notification as read' });
  }
});

// Mark all notifications as read
router.patch('/mark-all-read', async (req, res) => {
  try {
    let userId = req.user.id;
    let userEmail = req.user.email;

    // If employee, get employee email
    if (req.user.role === 'employee') {
      const employeeData = await getEmployeeId(userId);
      if (employeeData) {
        userEmail = employeeData.email;
      }
    }

    const { error } = await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('recipient_email', userEmail)
      .eq('is_read', false);

    if (error) throw error;

    res.json({ message: 'All notifications marked as read' });
  } catch (error) {
    console.error('Mark all as read error:', error);
    res.status(500).json({ message: 'Failed to mark all as read' });
  }
});

// Delete notification
router.delete('/:id', async (req, res) => {
  try {
    const { error } = await supabase
      .from('notifications')
      .delete()
      .eq('id', req.params.id);

    if (error) throw error;

    res.json({ message: 'Notification deleted successfully' });
  } catch (error) {
    console.error('Delete notification error:', error);
    res.status(500).json({ message: 'Failed to delete notification' });
  }
});

// Helper function to create notification
export const createNotification = async (recipientEmail, type, title, message) => {
  try {
    const { error } = await supabase
      .from('notifications')
      .insert({
        recipient_email: recipientEmail,
        type,
        title,
        message
      });

    if (error) throw error;
    return true;
  } catch (error) {
    console.error('Create notification error:', error);
    return false;
  }
};

export default router;
