import express from 'express';
import pool from '../config/database.js';
import { authenticateToken, authorizeRole } from '../middleware/auth.js';

const router = express.Router();

// Apply authentication and employee authorization to all routes
router.use(authenticateToken);
router.use(authorizeRole('employee'));

// Get employee ID from user ID
const getEmployeeId = async (userId) => {
  const [employees] = await pool.query('SELECT id FROM employees WHERE user_id = ?', [userId]);
  return employees.length > 0 ? employees[0].id : null;
};

// ===== DASHBOARD =====

router.get('/dashboard/stats', async (req, res) => {
  try {
    const employeeId = await getEmployeeId(req.user.id);
    
    if (!employeeId) {
      return res.status(404).json({ message: 'Employee record not found' });
    }

    const [leaveBalance] = await pool.query(
      'SELECT COUNT(*) as count FROM leaves WHERE employee_id = ? AND status = "approved" AND YEAR(from_date) = YEAR(CURDATE())',
      [employeeId]
    );

    const [pendingLeaves] = await pool.query(
      'SELECT COUNT(*) as count FROM leaves WHERE employee_id = ? AND status = "pending"',
      [employeeId]
    );

    const [attendanceIssues] = await pool.query(
      'SELECT COUNT(*) as count FROM attendance WHERE employee_id = ? AND status = "pending"',
      [employeeId]
    );

    const [payslipCount] = await pool.query(
      'SELECT COUNT(*) as count FROM payslips WHERE employee_id = ?',
      [employeeId]
    );

    res.json({
      leavesTaken: leaveBalance[0].count,
      pendingLeaves: pendingLeaves[0].count,
      attendanceIssues: attendanceIssues[0].count,
      payslipsCount: payslipCount[0].count
    });
  } catch (error) {
    console.error('Dashboard stats error:', error);
    res.status(500).json({ message: 'Failed to fetch dashboard stats' });
  }
});

// ===== PROFILE =====

router.get('/profile', async (req, res) => {
  try {
    const [employees] = await pool.query(
      `SELECT e.*, u.email 
       FROM employees e 
       JOIN users u ON e.user_id = u.id 
       WHERE u.id = ?`,
      [req.user.id]
    );

    if (employees.length === 0) {
      return res.status(404).json({ message: 'Profile not found' });
    }

    // Remove sensitive data
    const profile = employees[0];
    delete profile.user_id;

    res.json(profile);
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({ message: 'Failed to fetch profile' });
  }
});

router.put('/profile', async (req, res) => {
  try {
    const { phone, address } = req.body;
    const employeeId = await getEmployeeId(req.user.id);

    if (!employeeId) {
      return res.status(404).json({ message: 'Employee record not found' });
    }

    await pool.query(
      'UPDATE employees SET phone = ?, address = ? WHERE id = ?',
      [phone, address, employeeId]
    );

    res.json({ message: 'Profile updated successfully' });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ message: 'Failed to update profile' });
  }
});

// ===== LEAVE REQUESTS =====

router.get('/leaves', async (req, res) => {
  try {
    const employeeId = await getEmployeeId(req.user.id);

    if (!employeeId) {
      return res.status(404).json({ message: 'Employee record not found' });
    }

    const [leaves] = await pool.query(
      'SELECT * FROM leaves WHERE employee_id = ? ORDER BY created_at DESC',
      [employeeId]
    );

    res.json(leaves);
  } catch (error) {
    console.error('Get leaves error:', error);
    res.status(500).json({ message: 'Failed to fetch leave requests' });
  }
});

router.post('/leaves', async (req, res) => {
  try {
    const { type, from_date, to_date, reason } = req.body;
    const employeeId = await getEmployeeId(req.user.id);

    if (!employeeId) {
      return res.status(404).json({ message: 'Employee record not found' });
    }

    const [result] = await pool.query(
      'INSERT INTO leaves (employee_id, type, from_date, to_date, reason) VALUES (?, ?, ?, ?, ?)',
      [employeeId, type, from_date, to_date, reason]
    );

    res.status(201).json({ 
      message: 'Leave request submitted successfully',
      leaveId: result.insertId
    });
  } catch (error) {
    console.error('Create leave error:', error);
    res.status(500).json({ message: 'Failed to submit leave request' });
  }
});

// ===== ATTENDANCE ISSUES =====

router.get('/attendance', async (req, res) => {
  try {
    const employeeId = await getEmployeeId(req.user.id);

    if (!employeeId) {
      return res.status(404).json({ message: 'Employee record not found' });
    }

    const [attendance] = await pool.query(
      'SELECT * FROM attendance WHERE employee_id = ? ORDER BY created_at DESC',
      [employeeId]
    );

    res.json(attendance);
  } catch (error) {
    console.error('Get attendance error:', error);
    res.status(500).json({ message: 'Failed to fetch attendance records' });
  }
});

router.post('/attendance', async (req, res) => {
  try {
    const { date, time_in, time_out, reason } = req.body;
    const employeeId = await getEmployeeId(req.user.id);

    if (!employeeId) {
      return res.status(404).json({ message: 'Employee record not found' });
    }

    const [result] = await pool.query(
      'INSERT INTO attendance (employee_id, date, time_in, time_out, reason) VALUES (?, ?, ?, ?, ?)',
      [employeeId, date, time_in, time_out, reason]
    );

    res.status(201).json({ 
      message: 'Attendance issue submitted successfully',
      attendanceId: result.insertId
    });
  } catch (error) {
    console.error('Create attendance error:', error);
    res.status(500).json({ message: 'Failed to submit attendance issue' });
  }
});

// ===== PAYSLIPS =====

router.get('/payslips', async (req, res) => {
  try {
    const employeeId = await getEmployeeId(req.user.id);

    if (!employeeId) {
      return res.status(404).json({ message: 'Employee record not found' });
    }

    const [payslips] = await pool.query(
      'SELECT * FROM payslips WHERE employee_id = ? ORDER BY year DESC, month DESC',
      [employeeId]
    );

    res.json(payslips);
  } catch (error) {
    console.error('Get payslips error:', error);
    res.status(500).json({ message: 'Failed to fetch payslips' });
  }
});

router.get('/payslips/:id', async (req, res) => {
  try {
    const employeeId = await getEmployeeId(req.user.id);

    if (!employeeId) {
      return res.status(404).json({ message: 'Employee record not found' });
    }

    const [payslips] = await pool.query(
      'SELECT * FROM payslips WHERE id = ? AND employee_id = ?',
      [req.params.id, employeeId]
    );

    if (payslips.length === 0) {
      return res.status(404).json({ message: 'Payslip not found' });
    }

    res.json(payslips[0]);
  } catch (error) {
    console.error('Get payslip error:', error);
    res.status(500).json({ message: 'Failed to fetch payslip' });
  }
});

export default router;
