import { createClient } from '@supabase/supabase-js';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';

dotenv.config();

// Initialize Supabase client
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  throw new Error('Missing Supabase credentials. Please set SUPABASE_URL and SUPABASE_SERVICE_KEY in .env');
}

const supabase = createClient(supabaseUrl, supabaseServiceKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false
  }
});

export const initDatabase = async () => {
  try {
    // Test connection by making a simple query
    const { data, error } = await supabase.from('users').select('count', { count: 'exact', head: true });
    
    if (error && error.code !== 'PGRST116') { // PGRST116 = table doesn't exist yet (expected on first run)
      throw error;
    }
    
    console.log('✅ Supabase connected successfully');
    console.log('⚠️  Note: Please run the SQL schema from backend/supabase-schema.sql in your Supabase SQL Editor if you haven\'t already');
    
    // Create default admin if not exists
    await createDefaultAdmin();
    
    return true;
  } catch (error) {
    console.error('❌ Supabase connection failed:', error.message);
    throw error;
  }
};


const createDefaultAdmin = async () => {
  // Check if admin already exists
  const { data: existingAdmin, error: selectError } = await supabase
    .from('users')
    .select('*')
    .eq('role', 'admin')
    .limit(1);

  if (selectError) {
    console.error('Error checking for existing admin:', selectError.message);
    return;
  }

  if (!existingAdmin || existingAdmin.length === 0) {
    const hashedPassword = await bcrypt.hash(process.env.ADMIN_PASSWORD || 'admin123', 10);
    
    const { error: insertError } = await supabase
      .from('users')
      .insert({
        email: process.env.ADMIN_EMAIL || 'admin@orelit.com',
        password: hashedPassword,
        role: 'admin',
        must_change_password: false
      });

    if (insertError) {
      console.error('Error creating default admin:', insertError.message);
    } else {
      console.log('✅ Default admin created');
    }
  }
};

export default supabase;
